package com.example.inventoryapp_josemoralesegipciaco;

/**
 * Model class representing an inventory item
 * Updated for Project Three with database ID support
 */
public class InventoryItem {
    private long id; // Database ID
    private String itemName;
    private int quantity;
    private int lowStockThreshold;

    /**
     * Constructor without ID (for creating new items)
     * @param itemName Name of the inventory item
     * @param quantity Current quantity in stock
     * @param lowStockThreshold Threshold below which low stock alert is triggered
     */
    public InventoryItem(String itemName, int quantity, int lowStockThreshold) {
        this.id = -1; // -1 indicates item not yet saved to database
        this.itemName = itemName;
        this.quantity = quantity;
        this.lowStockThreshold = lowStockThreshold;
    }

    /**
     * Constructor with ID (for items loaded from database)
     * @param id Database ID
     * @param itemName Name of the inventory item
     * @param quantity Current quantity in stock
     * @param lowStockThreshold Threshold below which low stock alert is triggered
     */
    public InventoryItem(long id, String itemName, int quantity, int lowStockThreshold) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.lowStockThreshold = lowStockThreshold;
    }

    // Getters
    public long getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }

    // Setters
    public void setId(long id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setLowStockThreshold(int lowStockThreshold) {
        this.lowStockThreshold = lowStockThreshold;
    }

    /**
     * Checks if this item is below the low stock threshold
     * @return true if quantity is below threshold, false otherwise
     */
    public boolean isLowStock() {
        return quantity < lowStockThreshold;
    }

    @Override
    public String toString() {
        return "InventoryItem{" +
                "id=" + id +
                ", itemName='" + itemName + '\'' +
                ", quantity=" + quantity +
                ", lowStockThreshold=" + lowStockThreshold +
                ", isLowStock=" + isLowStock() +
                '}';
    }
}