package com.example.inventoryapp_josemoralesegipciaco;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

/**
 * LoginActivity handles user authentication
 * Updated for Project Three with database integration
 */
public class LoginActivity extends AppCompatActivity {

    // UI components
    private TextInputEditText usernameEditText;
    private TextInputEditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    // Database helper
    private DatabaseHelper databaseHelper;

    // SharedPreferences for remembering logged-in user
    private static final String PREFS_NAME = "InventoryAppPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_REMEMBER_ME = "remember_me";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Check if user is already logged in
        if (checkRememberedUser()) {
            return; // User was remembered, already navigated to MainActivity
        }

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Set up text watchers to enable/disable login button
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateInputs();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not needed
            }
        };

        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);

        // Login button click listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        // Create account button click listener
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCreateAccount();
            }
        });
    }

    /**
     * Checks if there's a remembered user and navigates to MainActivity if so
     * @return true if user was remembered, false otherwise
     */
    private boolean checkRememberedUser() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean rememberMe = prefs.getBoolean(KEY_REMEMBER_ME, false);

        if (rememberMe) {
            String username = prefs.getString(KEY_USERNAME, null);
            if (username != null && !username.isEmpty()) {
                // User should stay logged in
                navigateToMainActivity(username);
                return true;
            }
        }
        return false;
    }

    /**
     * Validates input fields and enables/disables login button
     */
    private void validateInputs() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Enable login button only if both fields have content
        boolean isValid = !username.isEmpty() && !password.isEmpty();
        loginButton.setEnabled(isValid);
    }

    /**
     * Handles login action with database authentication
     */
    private void handleLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input length
        if (username.length() < 3) {
            Toast.makeText(this, R.string.error_invalid_username, Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, R.string.error_invalid_password, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check credentials against database
        boolean isValidUser = databaseHelper.checkUser(username, password);

        if (isValidUser) {
            // Login successful
            Toast.makeText(this, R.string.login_successful, Toast.LENGTH_SHORT).show();

            // Save username for this session (remember user)
            saveUserSession(username);

            // Navigate to MainActivity
            navigateToMainActivity(username);
        } else {
            // Login failed
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles create account action with database insertion
     */
    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        if (username.length() < 3) {
            Toast.makeText(this, R.string.error_invalid_username, Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, R.string.error_invalid_password, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username already exists
        if (databaseHelper.checkUsername(username)) {
            Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to create new user in database
        boolean userCreated = databaseHelper.addUser(username, password);

        if (userCreated) {
            // Account creation successful
            Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();

            // Save username for this session
            saveUserSession(username);

            // Navigate to MainActivity
            navigateToMainActivity(username);
        } else {
            // Account creation failed
            Toast.makeText(this, "Failed to create account. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Saves user session to SharedPreferences
     * @param username Username to remember
     */
    private void saveUserSession(String username) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_USERNAME, username);
        editor.putBoolean(KEY_REMEMBER_ME, true);
        editor.apply();
    }

    /**
     * Navigates to MainActivity with username
     * @param username Logged-in username
     */
    private void navigateToMainActivity(String username) {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
        finish(); // Close login activity so user can't go back
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close database connection when activity is destroyed
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}