package com.example.inventoryapp_josemoralesegipciaco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper class for managing SQLite database operations
 * Handles both user authentication and inventory management
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "InventoryManager.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_LOW_STOCK_THRESHOLD = "low_stock_threshold";
    private static final String COLUMN_OWNER_USERNAME = "owner_username";

    // SQL statements for creating tables
    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                    COLUMN_PASSWORD + " TEXT NOT NULL)";

    private static final String CREATE_TABLE_INVENTORY =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                    COLUMN_QUANTITY + " INTEGER NOT NULL, " +
                    COLUMN_LOW_STOCK_THRESHOLD + " INTEGER NOT NULL, " +
                    COLUMN_OWNER_USERNAME + " TEXT NOT NULL, " +
                    "FOREIGN KEY(" + COLUMN_OWNER_USERNAME + ") REFERENCES " +
                    TABLE_USERS + "(" + COLUMN_USERNAME + "))";

    /**
     * Constructor
     * @param context Application context
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables when database is first created
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_INVENTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ========== USER AUTHENTICATION METHODS ==========

    /**
     * Adds a new user to the database
     * @param username Username
     * @param password Password (should be hashed in production)
     * @return true if user was added successfully, false otherwise
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password); // Note: In production, hash the password!

        try {
            long result = db.insert(TABLE_USERS, null, values);
            return result != -1; // Returns true if insertion was successful
        } catch (Exception e) {
            return false; // Username already exists or other error
        } finally {
            db.close();
        }
    }

    /**
     * Checks if a username already exists in the database
     * @param username Username to check
     * @return true if username exists, false otherwise
     */
    public boolean checkUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COLUMN_USERNAME},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * Validates user credentials
     * @param username Username
     * @param password Password
     * @return true if credentials are valid, false otherwise
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return isValid;
    }

    // ========== INVENTORY CRUD OPERATIONS ==========

    /**
     * Adds a new inventory item to the database
     * @param item InventoryItem object to add
     * @param username Owner of the item
     * @return Item ID if successful, -1 otherwise
     */
    public long addInventoryItem(InventoryItem item, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, item.getItemName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_LOW_STOCK_THRESHOLD, item.getLowStockThreshold());
        values.put(COLUMN_OWNER_USERNAME, username);

        long id = db.insert(TABLE_INVENTORY, null, values);
        db.close();

        // Set the ID in the item object
        if (id != -1) {
            item.setId(id);
        }

        return id;
    }

    /**
     * Retrieves all inventory items for a specific user
     * @param username Owner username
     * @return List of InventoryItem objects
     */
    public List<InventoryItem> getAllInventoryItems(String username) {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                new String[]{COLUMN_ITEM_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY, COLUMN_LOW_STOCK_THRESHOLD},
                COLUMN_OWNER_USERNAME + "=?",
                new String[]{username},
                null, null,
                COLUMN_ITEM_NAME + " ASC" // Sort by item name alphabetically
        );

        // Loop through all rows and add to list
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
                int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_LOW_STOCK_THRESHOLD));

                InventoryItem item = new InventoryItem(itemName, quantity, threshold);
                item.setId(id);
                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return itemList;
    }

    /**
     * Updates an existing inventory item
     * @param item InventoryItem object with updated values
     * @return Number of rows affected (should be 1 if successful)
     */
    public int updateInventoryItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, item.getItemName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_LOW_STOCK_THRESHOLD, item.getLowStockThreshold());

        int rowsAffected = db.update(
                TABLE_INVENTORY,
                values,
                COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(item.getId())}
        );

        db.close();
        return rowsAffected;
    }

    /**
     * Deletes an inventory item from the database
     * @param itemId ID of the item to delete
     * @return Number of rows affected (should be 1 if successful)
     */
    public int deleteInventoryItem(long itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsAffected = db.delete(
                TABLE_INVENTORY,
                COLUMN_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsAffected;
    }

    /**
     * Gets count of items that are below their low stock threshold
     * @param username Owner username
     * @return Count of low stock items
     */
    public int getLowStockItemCount(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query for items where quantity < low_stock_threshold
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_INVENTORY +
                        " WHERE " + COLUMN_OWNER_USERNAME + "=? AND " +
                        COLUMN_QUANTITY + " < " + COLUMN_LOW_STOCK_THRESHOLD,
                new String[]{username}
        );

        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        db.close();
        return count;
    }

    /**
     * Gets all items that are below their low stock threshold
     * @param username Owner username
     * @return List of low stock items
     */
    public List<InventoryItem> getLowStockItems(String username) {
        List<InventoryItem> lowStockItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY +
                        " WHERE " + COLUMN_OWNER_USERNAME + "=? AND " +
                        COLUMN_QUANTITY + " < " + COLUMN_LOW_STOCK_THRESHOLD,
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
                int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_LOW_STOCK_THRESHOLD));

                InventoryItem item = new InventoryItem(itemName, quantity, threshold);
                item.setId(id);
                lowStockItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lowStockItems;
    }
}