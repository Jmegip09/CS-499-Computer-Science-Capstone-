package com.example.inventoryapp_josemoralesegipciaco;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView Adapter for displaying inventory items
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<InventoryItem> inventoryItems;
    private OnItemActionListener listener;

    /**
     * Interface for handling item actions
     */
    public interface OnItemActionListener {
        void onDeleteClick(int position);
        void onItemClick(int position);
    }

    /**
     * Constructor
     * @param inventoryItems List of inventory items
     * @param listener Listener for item actions
     */
    public InventoryAdapter(List<InventoryItem> inventoryItems, OnItemActionListener listener) {
        this.inventoryItems = inventoryItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = inventoryItems.get(position);
        holder.bind(item, position);
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    /**
     * ViewHolder class for inventory items
     */
    class InventoryViewHolder extends RecyclerView.ViewHolder {
        private TextView itemNameTextView;
        private TextView quantityTextView;
        private TextView thresholdTextView;
        private ImageButton deleteButton;
        private View lowStockIndicator;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            thresholdTextView = itemView.findViewById(R.id.thresholdTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            lowStockIndicator = itemView.findViewById(R.id.lowStockIndicator);
        }

        /**
         * Binds inventory item data to the view
         * @param item Inventory item to bind
         * @param position Position in the list
         */
        public void bind(InventoryItem item, int position) {
            itemNameTextView.setText(item.getItemName());
            quantityTextView.setText(String.valueOf(item.getQuantity()));
            thresholdTextView.setText(String.valueOf(item.getLowStockThreshold()));

            // Show low stock indicator if quantity is below threshold
            if (item.isLowStock()) {
                lowStockIndicator.setVisibility(View.VISIBLE);
                // Optionally change text color to red for low stock items
                quantityTextView.setTextColor(itemView.getContext().getResources().getColor(android.R.color.holo_red_dark));
            } else {
                lowStockIndicator.setVisibility(View.GONE);
                quantityTextView.setTextColor(itemView.getContext().getResources().getColor(android.R.color.black));
            }

            // Set delete button click listener
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onDeleteClick(getAdapterPosition());
                    }
                }
            });
        }
    }
}