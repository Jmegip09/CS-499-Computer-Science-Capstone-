package com.example.inventoryapp_josemoralesegipciaco;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity displays and manages inventory items
 * Updated for Project Three with full database integration and SMS notifications
 */
public class MainActivity extends AppCompatActivity {

    // Constants
    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "InventoryAppPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_REMEMBER_ME = "remember_me";
    private static final String KEY_SMS_PHONE = "sms_phone_number";

    // UI components
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryItems;
    private FloatingActionButton addItemFab;
    private MaterialCardView smsPermissionCard;
    private Button enableSmsButton;
    private View emptyStateLayout;
    private Toolbar toolbar;

    // Database and user info
    private DatabaseHelper databaseHelper;
    private String currentUsername;
    private String smsPhoneNumber; // Phone number for SMS notifications

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemFab = findViewById(R.id.addItemFab);
        smsPermissionCard = findViewById(R.id.smsPermissionCard);
        enableSmsButton = findViewById(R.id.enableSmsButton);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);

        // Get username from intent or SharedPreferences
        currentUsername = getIntent().getStringExtra("username");
        if (currentUsername == null) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            currentUsername = prefs.getString(KEY_USERNAME, null);
        }

        // If still no username, redirect to login
        if (currentUsername == null) {
            navigateToLogin();
            return;
        }

        // Load SMS phone number from preferences
        loadSmsPhoneNumber();

        // Set toolbar title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(currentUsername + "'s Inventory");
        }

        // Initialize inventory list
        inventoryItems = new ArrayList<>();

        // Load inventory items from database
        loadInventoryFromDatabase();

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(inventoryItems, new InventoryAdapter.OnItemActionListener() {
            @Override
            public void onDeleteClick(int position) {
                deleteItem(position);
            }

            @Override
            public void onItemClick(int position) {
                showEditItemDialog(position);
            }
        });
        recyclerView.setAdapter(adapter);

        // Update empty state visibility
        updateEmptyState();

        // Set up FAB click listener
        addItemFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });

        // Set up SMS permission button
        enableSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        // Check if SMS permission is already granted
        checkSmsPermission();
    }

    /**
     * Loads inventory items from database for current user
     */
    private void loadInventoryFromDatabase() {
        inventoryItems.clear();
        List<InventoryItem> dbItems = databaseHelper.getAllInventoryItems(currentUsername);
        inventoryItems.addAll(dbItems);
    }

    /**
     * Loads SMS phone number from SharedPreferences
     */
    private void loadSmsPhoneNumber() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        smsPhoneNumber = prefs.getString(KEY_SMS_PHONE, null);
    }

    /**
     * Saves SMS phone number to SharedPreferences
     */
    private void saveSmsPhoneNumber(String phoneNumber) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_SMS_PHONE, phoneNumber);
        editor.apply();
        this.smsPhoneNumber = phoneNumber;
    }

    /**
     * Shows dialog to add a new inventory item
     */
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        TextInputEditText itemNameEditText = dialogView.findViewById(R.id.itemNameEditText);
        TextInputEditText quantityEditText = dialogView.findViewById(R.id.quantityEditText);
        TextInputEditText thresholdEditText = dialogView.findViewById(R.id.thresholdEditText);
        Button cancelButton = dialogView.findViewById(R.id.cancelButton);
        Button saveButton = dialogView.findViewById(R.id.saveButton);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = itemNameEditText.getText().toString().trim();
                String quantityStr = quantityEditText.getText().toString().trim();
                String thresholdStr = thresholdEditText.getText().toString().trim();

                // Validate inputs
                if (itemName.isEmpty() || quantityStr.isEmpty() || thresholdStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int quantity = Integer.parseInt(quantityStr);
                    int threshold = Integer.parseInt(thresholdStr);

                    // Validate non-negative numbers
                    if (quantity < 0 || threshold < 0) {
                        Toast.makeText(MainActivity.this, "Quantity and threshold must be positive", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Create new inventory item
                    InventoryItem newItem = new InventoryItem(itemName, quantity, threshold);

                    // Add to database
                    long itemId = databaseHelper.addInventoryItem(newItem, currentUsername);

                    if (itemId != -1) {
                        // Successfully added to database
                        newItem.setId(itemId);
                        inventoryItems.add(newItem);
                        adapter.notifyItemInserted(inventoryItems.size() - 1);
                        updateEmptyState();

                        Toast.makeText(MainActivity.this, R.string.item_added, Toast.LENGTH_SHORT).show();

                        // Check if we need to send SMS notification
                        if (newItem.isLowStock()) {
                            sendLowStockNotification(newItem);
                        }

                        dialog.dismiss();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to add item to database", Toast.LENGTH_SHORT).show();
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.show();
    }

    /**
     * Shows dialog to edit an existing inventory item
     * @param position Position of the item in the list
     */
    private void showEditItemDialog(int position) {
        InventoryItem item = inventoryItems.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        // Get views and pre-fill with current values
        TextInputEditText itemNameEditText = dialogView.findViewById(R.id.itemNameEditText);
        TextInputEditText quantityEditText = dialogView.findViewById(R.id.quantityEditText);
        TextInputEditText thresholdEditText = dialogView.findViewById(R.id.thresholdEditText);
        Button cancelButton = dialogView.findViewById(R.id.cancelButton);
        Button saveButton = dialogView.findViewById(R.id.saveButton);

        // Pre-fill with existing values
        itemNameEditText.setText(item.getItemName());
        quantityEditText.setText(String.valueOf(item.getQuantity()));
        thresholdEditText.setText(String.valueOf(item.getLowStockThreshold()));

        // Change button text to "Update"
        saveButton.setText("Update");

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = itemNameEditText.getText().toString().trim();
                String quantityStr = quantityEditText.getText().toString().trim();
                String thresholdStr = thresholdEditText.getText().toString().trim();

                // Validate inputs
                if (itemName.isEmpty() || quantityStr.isEmpty() || thresholdStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int quantity = Integer.parseInt(quantityStr);
                    int threshold = Integer.parseInt(thresholdStr);

                    if (quantity < 0 || threshold < 0) {
                        Toast.makeText(MainActivity.this, "Quantity and threshold must be positive", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Check if item is becoming low stock (wasn't before, but is now)
                    boolean wasLowStock = item.isLowStock();

                    // Update item values
                    item.setItemName(itemName);
                    item.setQuantity(quantity);
                    item.setLowStockThreshold(threshold);

                    // Update in database
                    int rowsAffected = databaseHelper.updateInventoryItem(item);

                    if (rowsAffected > 0) {
                        // Successfully updated
                        adapter.notifyItemChanged(position);
                        Toast.makeText(MainActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();

                        // Send notification if item just became low stock
                        if (!wasLowStock && item.isLowStock()) {
                            sendLowStockNotification(item);
                        }

                        dialog.dismiss();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to update item", Toast.LENGTH_SHORT).show();
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.show();
    }

    /**
     * Deletes an item from the inventory
     * @param position Position of the item in the list
     */
    private void deleteItem(int position) {
        InventoryItem item = inventoryItems.get(position);

        // Show confirmation dialog
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete '" + item.getItemName() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Delete from database
                    int rowsAffected = databaseHelper.deleteInventoryItem(item.getId());

                    if (rowsAffected > 0) {
                        // Successfully deleted
                        inventoryItems.remove(position);
                        adapter.notifyItemRemoved(position);
                        updateEmptyState();
                        Toast.makeText(MainActivity.this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Updates visibility of empty state layout
     */
    private void updateEmptyState() {
        if (inventoryItems.isEmpty()) {
            emptyStateLayout.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyStateLayout.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Checks if SMS permission is granted
     */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted - hide the permission card
            smsPermissionCard.setVisibility(View.GONE);

            // If phone number not set, prompt user to enter it
            if (smsPhoneNumber == null || smsPhoneNumber.isEmpty()) {
                promptForPhoneNumber();
            }
        } else {
            // Permission not granted - show the permission card
            smsPermissionCard.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Prompts user to enter their phone number for SMS notifications
     */
    private void promptForPhoneNumber() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Phone Number");
        builder.setMessage("Please enter your phone number to receive low stock alerts:");

        // Create input field
        final TextInputEditText input = new TextInputEditText(this);
        input.setHint("1234567890");
        input.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String phoneNumber = input.getText().toString().trim();
            if (!phoneNumber.isEmpty()) {
                saveSmsPhoneNumber(phoneNumber);
                Toast.makeText(MainActivity.this, "Phone number saved", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Skip", (dialog, which) -> {
            dialog.dismiss();
        });

        builder.show();
    }

    /**
     * Requests SMS permission from user
     */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // Show an explanation dialog
                new AlertDialog.Builder(this)
                        .setTitle(R.string.sms_permission_title)
                        .setMessage(R.string.sms_permission_message)
                        .setPositiveButton(R.string.allow, (dialog, which) -> {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.SEND_SMS},
                                    SMS_PERMISSION_CODE);
                        })
                        .setNegativeButton(R.string.deny, (dialog, which) -> {
                            smsPermissionCard.setVisibility(View.GONE);
                            Toast.makeText(MainActivity.this, R.string.sms_permission_denied,
                                    Toast.LENGTH_LONG).show();
                        })
                        .show();
            } else {
                // No explanation needed, request the permission directly
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        }
    }

    /**
     * Handles the result of permission request
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                smsPermissionCard.setVisibility(View.GONE);
                Toast.makeText(this, R.string.sms_permission_granted, Toast.LENGTH_LONG).show();

                // Prompt for phone number
                if (smsPhoneNumber == null || smsPhoneNumber.isEmpty()) {
                    promptForPhoneNumber();
                }

                // Check for any low stock items and notify
                checkAndNotifyLowStockItems();
            } else {
                // Permission denied
                smsPermissionCard.setVisibility(View.GONE);
                Toast.makeText(this, R.string.sms_permission_denied, Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Checks all items and sends notifications for low stock items
     */
    private void checkAndNotifyLowStockItems() {
        List<InventoryItem> lowStockItems = databaseHelper.getLowStockItems(currentUsername);

        if (!lowStockItems.isEmpty()) {
            for (InventoryItem item : lowStockItems) {
                sendLowStockNotification(item);
            }
        }
    }

    /**
     * Sends SMS notification for a low stock item
     * @param item The inventory item that is low on stock
     */
    private void sendLowStockNotification(InventoryItem item) {
        // Check if we have SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // No permission, can't send SMS
        }

        // Check if we have a phone number
        if (smsPhoneNumber == null || smsPhoneNumber.isEmpty()) {
            return; // No phone number set
        }

        try {
            // Create SMS message
            String message = "Low Stock Alert: " + item.getItemName() +
                    " is running low! Current quantity: " + item.getQuantity() +
                    ", Alert threshold: " + item.getLowStockThreshold();

            // Send SMS using SmsManager
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(smsPhoneNumber, null, message, null, null);

            // Show confirmation toast
            Toast.makeText(this, "SMS alert sent for " + item.getItemName(), Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            // Log error and show toast
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Creates options menu
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     * Handles options menu item selection
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_logout) {
            handleLogout();
            return true;
        } else if (id == R.id.action_set_phone) {
            promptForPhoneNumber();
            return true;
        } else if (id == R.id.action_check_low_stock) {
            showLowStockReport();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Shows a report of all low stock items
     */
    private void showLowStockReport() {
        List<InventoryItem> lowStockItems = databaseHelper.getLowStockItems(currentUsername);

        if (lowStockItems.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Low Stock Report")
                    .setMessage("All items are well stocked! ✓")
                    .setPositiveButton("OK", null)
                    .show();
        } else {
            StringBuilder report = new StringBuilder();
            report.append("The following items are low on stock:\n\n");

            for (InventoryItem item : lowStockItems) {
                report.append("• ").append(item.getItemName())
                        .append(": ").append(item.getQuantity())
                        .append(" (Alert at: ").append(item.getLowStockThreshold())
                        .append(")\n");
            }

            new AlertDialog.Builder(this)
                    .setTitle("Low Stock Report")
                    .setMessage(report.toString())
                    .setPositiveButton("OK", null)
                    .setNegativeButton("Send SMS Alerts", (dialog, which) -> {
                        checkAndNotifyLowStockItems();
                    })
                    .show();
        }
    }

    /**
     * Handles user logout
     */
    private void handleLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (dialog, which) -> {
                    // Clear remembered user
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean(KEY_REMEMBER_ME, false);
                    editor.apply();

                    // Navigate to login
                    navigateToLogin();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Navigates to LoginActivity
     */
    private void navigateToLogin() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh inventory when returning to this activity
        loadInventoryFromDatabase();
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close database connection when activity is destroyed
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}