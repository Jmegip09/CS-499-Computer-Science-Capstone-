package com.example.myapplication.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.data.model.InventoryItem

/**
 * RecyclerView Adapter for displaying inventory items.
 * Uses ListAdapter with DiffUtil for efficient updates.
 */
class InventoryAdapter : ListAdapter<InventoryItem, InventoryAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_inventory, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    /**
     * ViewHolder class that holds references to views in each item.
     * This improves performance by caching view references.
     */
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvItemName: TextView = itemView.findViewById(R.id.tvItemName)
        private val tvQuantity: TextView = itemView.findViewById(R.id.tvQuantity)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        private val lowStockIndicator: View = itemView.findViewById(R.id.lowStockIndicator)

        /**
         * Binds an InventoryItem to the views
         */
        fun bind(item: InventoryItem) {
            tvItemName.text = item.name
            tvQuantity.text = "Qty: ${item.quantity}"
            tvCategory.text = item.category ?: "Uncategorized"

            // Show red indicator if item is low on stock
            lowStockIndicator.visibility = if (item.isLowStock) View.VISIBLE else View.GONE
        }
    }

    /**
     * DiffUtil callback for calculating differences between old and new lists.
     * This allows RecyclerView to animate changes efficiently.
     */
    class DiffCallback : DiffUtil.ItemCallback<InventoryItem>() {
        override fun areItemsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem == newItem
        }
    }
}