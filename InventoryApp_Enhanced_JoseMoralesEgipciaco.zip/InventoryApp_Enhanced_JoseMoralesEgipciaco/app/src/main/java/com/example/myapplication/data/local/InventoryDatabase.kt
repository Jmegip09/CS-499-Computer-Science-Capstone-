package com.example.myapplication.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.myapplication.data.model.InventoryItem

/**
 * Room Database class for the Inventory app.
 *
 * @Database annotation tells Room:
 *   - entities: which table classes to include
 *   - version: schema version number (increment when you change the schema)
 *   - exportSchema: whether to save schema history to a file (good for migrations)
 *
 * This class follows the Singleton pattern — only one instance of the database
 * should exist at a time to prevent data races and resource waste.
 */
@Database(
    entities = [InventoryItem::class],
    version = 1,
    exportSchema = false
)
abstract class InventoryDatabase : RoomDatabase() {

    /**
     * Room uses this abstract function to provide the DAO implementation.
     * You never call this constructor directly — Room generates the class.
     */
    abstract fun inventoryDao(): InventoryDao

    companion object {
        // @Volatile ensures this value is always read from main memory,
        // never from a CPU cache — critical for thread safety.
        @Volatile
        private var INSTANCE: InventoryDatabase? = null

        /**
         * Get or create the database instance.
         * Uses double-checked locking for thread-safe singleton creation.
         *
         * @param context Application context (not Activity, to avoid memory leaks)
         */
        fun getDatabase(context: Context): InventoryDatabase {
            // If instance already exists, return it immediately (fast path)
            return INSTANCE ?: synchronized(this) {
                // Double-check inside the lock in case another thread
                // created it between our null check and acquiring the lock
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    InventoryDatabase::class.java,
                    "inventory_database"   // This becomes the .db filename on device
                ).build()

                INSTANCE = instance
                instance
            }
        }
    }
}