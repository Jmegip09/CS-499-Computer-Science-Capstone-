package com.example.myapplication.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.myapplication.data.model.InventoryItem

/**
 * Data Access Object (DAO) for inventory operations.
 *
 * This interface defines all the ways the app can interact with the database.
 * Room generates the full SQL implementation at compile time based on these annotations.
 *
 * Security note: Room uses parameterized queries by default, which prevents
 * SQL injection attacks — a major improvement over raw SQLite string concatenation.
 */
@Dao
interface InventoryDao {

    /**
     * Get all items, sorted alphabetically by name.
     * Returns LiveData so the UI automatically updates when data changes.
     * Room runs this query on a background thread automatically.
     */
    @Query("SELECT * FROM inventory_items ORDER BY name ASC")
    fun getAllItems(): LiveData<List<InventoryItem>>

    /**
     * Insert a new item. OnConflictStrategy.IGNORE means if an item with
     * the same primary key somehow already exists, skip the insert gracefully.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: InventoryItem)

    /**
     * Update an existing item. Room matches by primary key (id).
     */
    @Update
    suspend fun update(item: InventoryItem)

    /**
     * Delete an item. Room matches by primary key (id).
     */
    @Delete
    suspend fun delete(item: InventoryItem)

    /**
     * Search items by name (case-insensitive substring match).
     * The % wildcards allow partial matching, e.g. "app" matches "Apple".
     * Room safely parameterizes the query — no SQL injection possible.
     */
    @Query("SELECT * FROM inventory_items WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchByName(query: String): LiveData<List<InventoryItem>>

    /**
     * Get only items below their low stock threshold.
     * SQL compares quantity column directly to lowStockThreshold column.
     */
    @Query("SELECT * FROM inventory_items WHERE quantity < lowStockThreshold ORDER BY quantity ASC")
    fun getLowStockItems(): LiveData<List<InventoryItem>>

    /**
     * Get all items in a specific category.
     */
    @Query("SELECT * FROM inventory_items WHERE category = :category ORDER BY name ASC")
    fun getItemsByCategory(category: String): LiveData<List<InventoryItem>>

    /**
     * Get total item count — used for statistics dashboard.
     */
    @Query("SELECT COUNT(*) FROM inventory_items")
    suspend fun getTotalCount(): Int

    /**
     * Get count of low-stock items — used for statistics dashboard.
     */
    @Query("SELECT COUNT(*) FROM inventory_items WHERE quantity < lowStockThreshold")
    suspend fun getLowStockCount(): Int
}