package com.example.myapplication.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Data model representing an inventory item.
 *
 * @Entity tells Room this class maps to a database table named "inventory_items".
 * Each field becomes a column in that table.
 */
@Entity(tableName = "inventory_items")
data class InventoryItem(
    @PrimaryKey(autoGenerate = true)  // Room auto-assigns a unique ID
    val id: Int = 0,
    val name: String,
    val quantity: Int,
    val lowStockThreshold: Int,
    val category: String = "Uncategorized"
) {
    /**
     * Check if this item is below its low stock threshold.
     * Note: This is NOT stored in the database (no column created).
     * Room ignores computed properties automatically.
     */
    val isLowStock: Boolean
        get() = quantity < lowStockThreshold

    val threshold: Int
        get() = lowStockThreshold
}