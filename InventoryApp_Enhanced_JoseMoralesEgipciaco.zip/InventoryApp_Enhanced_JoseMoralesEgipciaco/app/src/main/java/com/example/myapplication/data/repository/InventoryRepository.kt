package com.example.myapplication.data.repository

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.myapplication.data.local.InventoryDatabase
import com.example.myapplication.data.model.InventoryItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Repository class that manages data access.
 * Part of MVVM architecture — the single source of truth for all inventory data.
 *
 * Now backed by Room (SQLite) instead of in-memory storage.
 * Data persists across app restarts.
 *
 * Enhanced with:
 * - Real database persistence via Room
 * - Coroutine-based async operations (no UI thread blocking)
 * - Statistical computation and caching
 * - Secure parameterized queries (SQL injection prevention via Room)
 */
class InventoryRepository(application: Application) {

    // Get the DAO from the database singleton
    private val inventoryDao = InventoryDatabase.getDatabase(application).inventoryDao()

    // LiveData directly from Room — automatically updates UI on data changes
    val inventoryItems: LiveData<List<InventoryItem>> = inventoryDao.getAllItems()

    // Cached statistics (computed from the current list)
    private val _statistics = MutableLiveData<InventoryStatistics>()
    val statistics: LiveData<InventoryStatistics> = _statistics

    /**
     * Get all inventory items as LiveData.
     * Room delivers updates automatically — no manual refresh needed.
     */
    fun getAllItems(): LiveData<List<InventoryItem>> = inventoryItems

    /**
     * Get only low-stock items directly from the database.
     * More efficient than loading all items and filtering in memory.
     */
    fun getLowStockItems(): LiveData<List<InventoryItem>> = inventoryDao.getLowStockItems()

    /**
     * Search items by name — database handles the filtering.
     */
    fun searchByName(query: String): LiveData<List<InventoryItem>> =
        inventoryDao.searchByName(query)

    /**
     * Insert a new item.
     * Runs on IO dispatcher (background thread) — never blocks the UI.
     */
    fun insert(item: InventoryItem) {
        CoroutineScope(Dispatchers.IO).launch {
            inventoryDao.insert(item)
            refreshStatistics()
        }
    }

    /**
     * Delete an item.
     * Runs on IO dispatcher (background thread).
     */
    fun delete(item: InventoryItem) {
        CoroutineScope(Dispatchers.IO).launch {
            inventoryDao.delete(item)
            refreshStatistics()
        }
    }

    /**
     * Update an existing item.
     * Runs on IO dispatcher (background thread).
     */
    fun update(item: InventoryItem) {
        CoroutineScope(Dispatchers.IO).launch {
            inventoryDao.update(item)
            refreshStatistics()
        }
    }

    // ============================================================================
    // STATISTICS
    // ============================================================================

    /**
     * Statistics data class — aggregates multiple metrics in one object.
     */
    data class InventoryStatistics(
        val totalItems: Int,
        val lowStockCount: Int,
        val totalQuantity: Int,
        val averageQuantity: Double,
        val categoryCounts: Map<String, Int>
    )

    /**
     * Refresh statistics from the database.
     * Queries the DB for counts, then computes derived metrics from the live list.
     * Posts result to main thread so LiveData observers (UI) can receive it.
     */
    private suspend fun refreshStatistics() {
        withContext(Dispatchers.IO) {
            val total = inventoryDao.getTotalCount()
            val lowStock = inventoryDao.getLowStockCount()

            // Compute remaining stats from the current in-memory list snapshot
            val currentItems = inventoryItems.value ?: emptyList()
            val totalQty = currentItems.sumOf { it.quantity }
            val avgQty = if (total > 0) totalQty.toDouble() / total else 0.0
            val categoryCounts = currentItems.groupingBy { it.category }.eachCount()

            val stats = InventoryStatistics(
                totalItems = total,
                lowStockCount = lowStock,
                totalQuantity = totalQty,
                averageQuantity = avgQty,
                categoryCounts = categoryCounts
            )

            // Post to main thread (LiveData requires main thread for setValue)
            withContext(Dispatchers.Main) {
                _statistics.value = stats
            }
        }
    }
}