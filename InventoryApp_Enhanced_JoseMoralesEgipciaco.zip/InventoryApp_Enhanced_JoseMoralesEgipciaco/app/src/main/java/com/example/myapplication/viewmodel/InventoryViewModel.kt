package com.example.myapplication.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.map
import com.example.myapplication.data.model.InventoryItem
import com.example.myapplication.data.repository.InventoryRepository

/**
 * ViewModel for managing inventory data.
 * Part of MVVM architecture - survives configuration changes.
 *
 * Enhanced with:
 * - Multiple sorting algorithms (O(n log n) complexity)
 * - Efficient filtering algorithms (O(n) complexity)
 * - Binary search for sorted lists (O(log n) complexity)
 * - Statistical aggregation
 * - Category-based grouping using Map data structure
 */
class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = InventoryRepository(application)

    // LiveData for UI to observe
    val items: LiveData<List<InventoryItem>> = repository.getAllItems()

    // Statistics from repository
    val statistics: LiveData<InventoryRepository.InventoryStatistics> = repository.statistics

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _message = MutableLiveData<String>()
    val message: LiveData<String> = _message

    // Sort and filter options
    private val _sortOption = MutableLiveData(SortOption.NAME_ASC)

    private val _filterOption = MutableLiveData(FilterOption.ALL)

    /**
     * Combined LiveData that applies both sorting and filtering.
     * Demonstrates reactive data transformation in MVVM.
     */
    val displayedItems: LiveData<List<InventoryItem>> = MediatorLiveData<List<InventoryItem>>().apply {
        addSource(items) { updateDisplayedItems() }
        addSource(_sortOption) { updateDisplayedItems() }
        addSource(_filterOption) { updateDisplayedItems() }
    }

    private fun MediatorLiveData<List<InventoryItem>>.updateDisplayedItems() {
        val currentItems = items.value ?: emptyList()
        val currentFilter = _filterOption.value ?: FilterOption.ALL
        val currentSort = _sortOption.value ?: SortOption.NAME_ASC

        val filtered = applyFilter(currentItems, currentFilter)
        val sorted = sortInventory(filtered, currentSort)
        this.value = sorted
    }

    // ============================================================================
    // SORTING ALGORITHMS
    // ============================================================================

    /**
     * Sort options enum for type-safe sorting
     */
    enum class SortOption {
        NAME_ASC,           // Alphabetical A-Z
        NAME_DESC,          // Alphabetical Z-A
        QUANTITY_ASC,       // Lowest quantity first
        QUANTITY_DESC,      // Highest quantity first
        LOW_STOCK_PRIORITY  // Low stock items first, then by quantity
    }

    /**
     * Sort inventory using specified algorithm.
     * Uses Kotlin's built-in TimSort (O(n log n) worst case).
     *
     * LOW_STOCK_PRIORITY uses composite comparator:
     * 1. First by stock status (low stock items first)
     * 2. Then by quantity (lowest first)
     *
     * This demonstrates understanding of:
     * - Comparison-based sorting
     * - Stable sort algorithms
     * - Composite sorting criteria
     */
    fun sortInventory(items: List<InventoryItem>, sortBy: SortOption): List<InventoryItem> {
        return when (sortBy) {
            SortOption.NAME_ASC -> items.sortedBy { it.name.lowercase() }
            SortOption.NAME_DESC -> items.sortedByDescending { it.name.lowercase() }
            SortOption.QUANTITY_ASC -> items.sortedBy { it.quantity }
            SortOption.QUANTITY_DESC -> items.sortedByDescending { it.quantity }
            SortOption.LOW_STOCK_PRIORITY -> items.sortedWith(
                compareBy<InventoryItem> { !it.isLowStock }  // Low stock first (false < true)
                    .thenBy { it.quantity }                   // Then by quantity ascending
            )
        }
    }

    /**
     * Update the current sort option.
     * Triggers automatic update of displayed items via MediatorLiveData.
     */
    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    // ============================================================================
    // FILTERING ALGORITHMS
    // ============================================================================

    /**
     * Filter options enum for type-safe filtering
     */
    enum class FilterOption {
        ALL,           // Show all items
        LOW_STOCK,     // Only items below threshold
        IN_STOCK,      // Only items at or above threshold
        CATEGORY       // Filter by specific category (requires category parameter)
    }

    /**
     * Apply filter to item list.
     * Linear search O(n) - examines each item once.
     */
    private fun applyFilter(items: List<InventoryItem>, filter: FilterOption): List<InventoryItem> {
        return when (filter) {
            FilterOption.ALL -> items
            FilterOption.LOW_STOCK -> filterLowStock(items)
            FilterOption.IN_STOCK -> items.filter { !it.isLowStock }
            FilterOption.CATEGORY -> items // Would need category parameter in real implementation
        }
    }

    /**
     * Filter to show only low-stock items.
     * O(n) time complexity - single pass through list.
     */
    fun filterLowStock(items: List<InventoryItem>): List<InventoryItem> {
        return items.filter { it.isLowStock }
    }

    /**
     * Filter by category with case-insensitive matching.
     * O(n) time complexity.
     */
    fun filterByCategory(items: List<InventoryItem>, category: String): List<InventoryItem> {
        return items.filter { it.category.equals(category, ignoreCase = true) }
    }

    /**
     * Search by name with case-insensitive substring matching.
     * O(n) time complexity.
     * Could be optimized with trie data structure for large datasets.
     */
    fun searchByName(items: List<InventoryItem>, query: String): List<InventoryItem> {
        if (query.isBlank()) return items
        return items.filter { it.name.contains(query, ignoreCase = true) }
    }

    /**
     * Update the current filter option.
     */
    fun setFilterOption(option: FilterOption) {
        _filterOption.value = option
    }

    // ============================================================================
    // SEARCH ALGORITHMS
    // ============================================================================

    /**
     * Binary search for sorted lists.
     * O(log n) time complexity - much faster than linear search for large lists.
     *
     * PRECONDITION: sortedItems must be sorted by name in ascending order.
     *
     * This demonstrates:
     * - Divide-and-conquer algorithm
     * - Logarithmic time complexity
     * - Algorithm preconditions and invariants
     *
     * @return index of item if found, -1 if not found
     */
    fun binarySearchByName(sortedItems: List<InventoryItem>, name: String): Int {
        var low = 0
        var high = sortedItems.size - 1

        while (low <= high) {
            val mid = (low + high) / 2
            val comparison = sortedItems[mid].name.compareTo(name, ignoreCase = true)

            when {
                comparison < 0 -> low = mid + 1  // Search right half
                comparison > 0 -> high = mid - 1 // Search left half
                else -> return mid               // Found!
            }
        }
        return -1 // Not found
    }

    // ============================================================================
    // DATA STRUCTURE OPERATIONS
    // ============================================================================

    /**
     * Group items by category using Map data structure.
     *
     * Demonstrates:
     * - Hash map for O(1) category lookup
     * - Grouping algorithm
     * - Space-time tradeoff (using more memory for faster access)
     *
     * Use case: Displaying expandable category sections in RecyclerView
     */
    fun groupByCategory(items: List<InventoryItem>): Map<String, List<InventoryItem>> {
        return items.groupBy { it.category }
    }

    /**
     * Get categorized inventory as LiveData for UI observation.
     * Automatically updates when inventory changes.
     */
    val categorizedInventory: LiveData<Map<String, List<InventoryItem>>> =
        items.map { itemList: List<InventoryItem> ->  // Explicit type annotation
            groupByCategory(itemList)
        }

    // ============================================================================
    // CRUD OPERATIONS
    // ============================================================================

    /**
     * Add a new inventory item with validation.
     */
    fun addItem(name: String, qtyText: String, thresholdText: String, category: String = "Uncategorized") {
        // Validate name
        if (name.isBlank()) {
            _message.value = "Item name is required"
            return
        }

        // Validate quantity
        val quantity = qtyText.toIntOrNull()
        if (quantity == null || quantity < 0) {
            _message.value = "Please enter a valid quantity"
            return
        }

        // Validate threshold
        val threshold = thresholdText.toIntOrNull()
        if (threshold == null || threshold < 0) {
            _message.value = "Please enter a valid threshold"
            return
        }

        _loading.value = true

        val item = InventoryItem(
            name = name.trim(),
            quantity = quantity,
            lowStockThreshold = threshold,
            category = category.trim()
        )

        try {
            repository.insert(item)
            _message.value = "Item added successfully"
        } catch (e: Exception) {
            _message.value = "Error adding item: ${e.message}"
        } finally {
            _loading.value = false
        }
    }

    /**
     * Delete an inventory item.
     */
    fun deleteItem(item: InventoryItem) {
        try {
            repository.delete(item)
            _message.value = "Item deleted"
        } catch (e: Exception) {
            _message.value = "Could not delete item: ${e.message}"
        }
    }

    /**
     * Update an existing inventory item.
     */
    fun updateItem(item: InventoryItem) {
        try {
            repository.update(item)
            _message.value = "Item updated"
        } catch (e: Exception) {
            _message.value = "Could not update item: ${e.message}"
        }
    }

    // ============================================================================
    // UTILITY FUNCTIONS
    // ============================================================================

    /**
     * Get list of unique categories from current inventory.
     * Useful for category filter dropdowns.
     */
    fun getUniqueCategories(): List<String> {
        return items.value?.map { it.category }?.distinct()?.sorted() ?: emptyList()
    }

    /**
     * Clear the current message.
     */
    fun clearMessage() {
        _message.value = null
    }
}