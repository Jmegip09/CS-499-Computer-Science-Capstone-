package com.example.myapplication.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.ActivityMainBinding
import com.example.myapplication.viewmodel.InventoryViewModel
import com.example.myapplication.viewmodel.InventoryViewModelFactory
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: InventoryViewModel by viewModels {
        InventoryViewModelFactory(application)
    }
    private val adapter = InventoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        // Observe LiveData
        viewModel.items.observe(this) { items ->
            adapter.submitList(items)
        }

        viewModel.loading.observe(this) { isLoading ->
            binding.progress.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.message.observe(this) { msg ->
            if (!msg.isNullOrBlank()) {
                Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
            }
        }

        // UI -> ViewModel (no business logic here)
        binding.btnAdd.setOnClickListener {
            viewModel.addItem(
                name = binding.inputName.text?.toString().orEmpty(),
                qtyText = binding.inputQty.text?.toString().orEmpty(),
                thresholdText = binding.inputThreshold.text?.toString().orEmpty()
            )
        }
    }
}
