package com.example.myapplication.util

object InputValidator {

    fun validateName(name: String): String? {
        if (name.trim().isEmpty()) return "Item name is required."
        return null
    }

    fun validateNonNegativeInt(valueText: String, fieldLabel: String): Pair<Int?, String?> {
        val v = valueText.trim()
        if (v.isEmpty()) return null to "$fieldLabel is required."
        val num = v.toIntOrNull() ?: return null to "$fieldLabel must be a number."
        if (num < 0) return null to "$fieldLabel cannot be negative."
        return num to null
    }
}